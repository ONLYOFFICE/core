/* 
 * The contents of this file are subject to the IBM Common Public
 * License Version 0.5 (the "License"); you may not use this file 
 * except in compliance with the License. You may obtain a copy of 
 * the License at http://oss.software.ibm.com/developerworks/
 * opensource/license-cpl.html
 * 
 * The Original Code is the Open Exif Toolkit,
 * released November 13, 2000.
 *
 * The Initial Developer of the Original Code is Eastman 
 * Kodak Company. Portions created by Kodak are 
 * Copyright (C) 2001 Eastman Kodak Company. All 
 * Rights Reserved. 
 *
 * Creation Date: 03/30/2003
 *
 * Original Author: 
 * Ricardo Rosario ricardo.rosario@kodak.com
 * 
 */
 
 /*
 * Program Usage:
 *    ExifTagDump <filename>
 *       where <filename> is the name of the Exif file to read the Exif Tags
 *       from.
 */
 
 // The files we need to include...
#include "ExifImageFile.h"
#include <iomanip>

using namespace std;

// The main entry point.
int main(int argc, char *argv[])
{
    int return_value = 0;
    
    // Verify that we have one command-line argument. If we don't, show the
    // usage and exit.
    if (argc == 2)
    {
        char * filename = argv[1];
        
        // Create instance of ExifImageFile
        ExifImageFile inImageFile;
        
        // Open the file in read-only mode and verify that it succeeds
        if ( inImageFile.open( filename, "r" ) == EXIF_OK)
        {
            // Get all the AppSeg 1 - "Exif" tags and output them
            cout << "App1 - \"Exif\" entries:" << endl;
            ExifPathsTags app1PathsTags ;
            inImageFile.getAllTags( 0xFFE1, "Exif", app1PathsTags ) ;

            ExifPathsTagsIter crntPathsTags = app1PathsTags.begin() ;
            ExifPathsTagsIter endPathsTags = app1PathsTags.end() ;
            while( crntPathsTags != endPathsTags )
            {
                ExifIFDPathIter crntPath = (*crntPathsTags).first.begin() ;
                ExifIFDPathIter endPath = (*crntPathsTags).first.end() ;
                while( crntPath != endPath )
                {
                    cout << "IFD: " << (*crntPath).first  ;
                    cout << "  Idx: " << (*crntPath).second << endl ;
                    crntPath++ ;
                }
         
                ExifTagsIter crnt = (*crntPathsTags).second.begin() ;
                ExifTagsIter end = (*crntPathsTags).second.end() ;
                
                cout << "Tag#\tType\tCount\tValue" << endl;
                while( crnt != end )
                {
                    ExifTagEntry* tag = *(crnt) ;
                    tag->print() ;
                    cout << endl ;
                    crnt++ ;
                }
                crntPathsTags++ ;
            }
            
            // Get all the AppSeg 3 - "Meta" tags and output them
            
            ExifPathsTags app3PathsTags ;
            inImageFile.getAllTags( 0xFFE3, "Meta", app3PathsTags ) ;

            crntPathsTags = app3PathsTags.begin() ;
            endPathsTags = app3PathsTags.end() ;
            if ( crntPathsTags != endPathsTags )
                cout << "\nApp3 - \"Meta\" entries:" << endl;
            while( crntPathsTags != endPathsTags )
            {
                ExifIFDPathIter crntPath = (*crntPathsTags).first.begin() ;
                ExifIFDPathIter endPath = (*crntPathsTags).first.end() ;
                while( crntPath != endPath )
                {
                    cout << "IFD: " << (*crntPath).first  ;
                    cout << "  Idx: " << (*crntPath).second << endl ;
                    crntPath++ ;
                }
         
                ExifTagsIter crnt = (*crntPathsTags).second.begin() ;
                ExifTagsIter end = (*crntPathsTags).second.end() ;
                
                cout << "Tag#\tType\tCount\tValue" << endl;
                while( crnt != end )
                {
                    ExifTagEntry* tag = *(crnt) ;
                    tag->print() ;
                    cout << endl ;
                    crnt++ ;
                }
                crntPathsTags++ ;
            }            

            //Now, recognition of any other app segments:
            // Get a vector with all the application segments in the file
            vector<ExifAppSegment*> appSegs = inImageFile.getAllAppSegs();
            
            // How many do we have?
            int numOfAppSegs = appSegs.size();
    
            cout << "\n\nNumber of Application Segments in " << filename <<
                ": " << numOfAppSegs << endl ;
            cout << "Marker\tLength\tIdent" << endl;
    
            // Loop through the application segments outputting their marker,
            // length and identifier.
            for ( int i = 0; i < numOfAppSegs; i++ )
            {
                cout << appSegs[i]->getAppSegmentMarker() << "\t";
                cout << appSegs[i]->getLength() << "\t";
                cout << appSegs[i]->getAppIdent() << endl;
            }
            
            
            // Now, lets output any COM marker data
            cout << endl << endl;
            ExifComMarkerList * comList = 
                     ( ExifComMarkerList * )inImageFile.getComData();
            const unsigned int comListSize = comList->size();
            for(unsigned int i = 0; i < comListSize; i++)
            {
                tsize_t dataSize;
                int j;
                ExifComMarker * marker = comList->getComMarker(i);
                const uint8 * comData = marker->getData(dataSize);
                cout << "COM Marker #" << i+1 << " Data" << endl;
                for (j = 0; j < dataSize; j++)
                    cout << setbase(16) << (unsigned short)comData[j] << " ";
                cout << endl;
                for (j = 0; j < dataSize; j++)
                    cout << comData[j];
                cout << endl << endl;
            }
            
            // And finally, let's output the SOF info
            ExifImageInfo info;
            inImageFile.getImageInfo(info);
            cout << "Image Information:\n";
            cout << "\twidth:\t\t" << info.width << endl;
            cout << "\theight:\t\t" << info.height << endl;
            cout << "\tchannels:\t" << info.numChannels << endl;
            cout << "\tbit depth:\t" << info.precision << endl;
           
            // Close the file
            if( inImageFile.close() != EXIF_OK )
            {
                cout << "Error: Could not close" << filename << endl;
                return_value = 1;
            }   
        }
        else
        {
            cout << "Error: could not open " << filename <<
                " with ExifImageFile." << endl;
            return_value = 1;   
        }
    }
    else
    {
        cout << " Usage: " << argv[0] << " <filename>\n";
        return_value = 1;
    }
        
    // return the status
    return return_value;
}
