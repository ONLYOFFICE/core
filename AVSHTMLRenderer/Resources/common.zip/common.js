﻿var oBigStatus;
var oErrorMessage;
var oInfoMessage;
var oWaitDownload = new WaitDownload();
var oMessageManager;

var oEditorConfig = {
	downloadTimeout: 3000,
	openTimeout: 3000,
	saveTimeout: 3000
};

$(function(){
	oMessageManager = new MessageManager();
	oBigStatus = new BigStatus();
	oErrorMessage = new ErrorMessage();
	oInfoMessage = new InfoMessage();
});

function BigStatus(){
    this._elem = $("#bigstatus");
	this._text = $("#bigTextStatus");
	this.bIsVisible = false;

	this.show = function(text){
		if( undefined != text ){
			this._text.text(text);		
		}
		this._elem.show();
		this.bIsVisible = true;
	};
	this.hide = function(){
		this._elem.hide();
		this.bIsVisible = false;
	};
	this.isVisible = function(){
		return this.bIsVisible;
	};
};
function ErrorMessage(){
	this._elem = $("#dialogErrorMessage");
	this._elemText = $("#ErrorMessageText");
	this._elem.dialog({autoOpen: false, title: oMessageManager.titles.errorMessage, closeOnEscape:false,
		resizable: false, modal: true,
		buttons: {"OK": function(){$(this).dialog("close");}}
	});
	this.show = function(text){
		this._elemText.text(text);
		this._elem.dialog("open");
	};
};
function InfoMessage(){
	this._elem = $("#dialogInfoMessage");
	this._elemText = $("#InfoMessageText");
	this._elem.dialog({autoOpen: false, title: oMessageManager.titles.infoMessage, closeOnEscape:false,
		resizable: false, modal: true,
		buttons: {"OK": function(){$(this).dialog("close");}}
	});
	this.show = function(text){
		this._elemText.text(text);
		this._elem.dialog("open");
	};
};
function WaitDownload(){
	this._id;
	this.url;
	this._title;
	this._filetype;
	this._valK;
	this._onError = function(){};
	this._onComplete = function(){};
	this.wait = function(id, url, title, filetype, valK, onError, onComplete){
		this._id = id;
		this._url = url;
		this._title = title;
		this._filetype = filetype;
		this._valK = valK;
		this._onError = onError;
		this._onComplete = onComplete;
		this._wait();
	};
	this._wait = function(check){
		var rdata = {val: this._id, url:this._url, title: this._title, filetype: this._filetype, valK: this._valK };
		var oThis = this;
		$.ajax({
			type: 'POST',
			url: "Download.ashx",
			data: JSON.stringify(rdata),
			error: function(jqXHR, textStatus, errorThrown){
					switch (textStatus){
						case "timeout":
							oThis._onError(oMessageManager.errors.serverTimeout);
							break;
						case "error":
							oThis._onError(oMessageManager.errors.serverError);
							break;
						case "abort":
							oThis._onError(oMessageManager.errors.serverAbort);
							break;
						case "parsererror":
							oThis._onError(oMessageManager.errors.serverParse);
							break;
						default:
							oThis._onError(oMessageManager.errors.serverUnknown);
							break;
					}
				},
			success: function(msg){
					if(msg==""){
						oThis._onError(oMessageManager.errors.serverEmptyResponse);
						return;
					}
					var incomeObject = JSON.parse(msg);
					switch(incomeObject.type){
						case "download":
							oThis._onComplete( incomeObject );
							break;
						case "downloading":
							setTimeout(function(){oThis._wait();}, oEditorConfig.downloadTimeout);
							break;
						case "err":
							oThis._onError( oMessageManager.getServerMessageString(incomeObject.val));
							break;
					}
				},
				dataType: "text"
			});
	};
};
function MessageManager(){
	this.errors={
		serverTimeout: $("#ServerTimeoutError").val(),
		serverError: $("#ServerError").val(),
		serverAbort: $("#ServerAbortError").val(),
		serverParse: $("#ServerParseError").val(),
		serverUnknown: $("#ServerUnknownError").val(),
		serverEmptyResponse: $("#EmptyServerResponse").val()
	};
	this.messages={
		openDocument: $("#OpenDocument").val(),
		downloadProgress: $("#DownloadDocument").val(),
		saveProgress: $("#SavingDocument").val(),
		changeTheme: $("#ChangingTheme").val()
	};
	this.titles={
		errorMessage: $("#ErrorMessage").val(),
		infoMessage: $("#InformationMessage").val()
	};
	this.getServerMessageString = function(sMessage){
		var sResult = "";
		var nMessage = sMessage - 0;
		switch(nMessage){
			case 2: sResult = $("#ConvertationInProgress").val();break;
			case 1: sResult = $("#DownloadInProgress").val();break;
			case 0: sResult = $("#NoError").val();break;
			case -1: sResult = $("#Unknown").val();break;	
			case -2: sResult = $("#ConvertationStopedByTimeout").val();break;
			case -3: sResult = $("#ConvertationError").val();break;
			case -4: sResult = $("#DownloadError").val();break;
			case -5: sResult = $("#UnexpectedGUID").val();break;
			case -6: sResult = $("#Database").val();break;
			case -7: sResult = $("#FileRequest").val();break;
			case -8: sResult = $("#ServerKeyError").val();break;
			default: sResult = sMessage;break;
		}
		return sResult;
	}
};
function ReplaceString(stringOld){
	var stringNew = stringOld;
	var nLengthFile = 23;
	
	if (stringOld.length > nLengthFile) {
		stringNew = stringOld.substring(0, nLengthFile - 1) + "...";
	}
	
	return stringNew;
};
