var currentPage = 1; var __arrOffset=[]; var bOnChangePage = true; var __page = 0;var winScroll = true;
function getBodyWidth(){
	var result = 0;
	if (this.innerWidth)  
		result = this.innerWidth;  
	else if (document.documentElement && document.documentElement.clientWidth)  
		result = document.documentElement.clientWidth;  
	else if (document.body)  
		result = document.body.clientWidth; 
	return result;
}
function getBodyHeight(){
	var result = 0;
	if (this.innerHeight)  
		result = this.innerHeight;  
	else if (document.documentElement && document.documentElement.clientHeight)  
		result = document.documentElement.clientHeight;  
	else if (document.body)  
		result = document.body.clientHeight; 
	return result;
}
function getScrollPos(){
	var result = 0;
	var bIsIE = /*@cc_on ! @*/ false;
	if (!document.documentElement || !bIsIE)  
		result = this.document.body.scrollTop;  
	else 
		result = document.documentElement.scrollTop;  
	return result;
}
function getScrollMax(){
	var result = 0;
	var bIsIE = /*@cc_on ! @*/ false;
	if (!document.documentElement || !bIsIE) 
		result = this.document.body.scrollMax;  
	else 
		result = document.documentElement.scrollHeight;  
	return result;
}
function OnChangePage(pageNum){
	// bOnChangePage = true;
	currentPage = pageNum;
	if (currentPage==1)
		$("#scrollbarV").scrollTop(0)//.scroll();
	else
		$("#scrollbarV").scrollTop(__arrOffset[currentPage-1]*dZoomKoef)//.scroll();
}
function OnScroll(evnt){
	// if (bOnChangePage){ bOnChangePage=false; return};
	var koef    = getScrollPos() / getScrollMax();
	var offsetCur = 16 + 20 * (nPagesCount - 1) + lHeightDoc;
	var offset  = $("#scrollbarV").scrollTop() / dZoomKoef;
	var min		= 0;
	var max		= nPagesCount - 1;
	while (min < max){
		var index = parseInt((min + max + 1) / 2);
		if (offset < __arrOffset[index]){
			max = index - 1;
		}
		else{
			min = index;
		}
	}
	if (min != (nPagesCount - 1)){
		var offset1 = __arrOffset[min + 1] - offset;
		var offset2 = offset + getBodyHeight() - __arrOffset[min + 1];
		if (offset2 > offset1)
			++min;
	}
		_currentPage = min+1;
		if (_currentPage > nPagesCount)
			currentPage = nPagesCount;
		else 
			currentPage = _currentPage;
		SetCurrentPage( currentPage)
}
function OnClick(){
	closeMenu();
}
function FitToPageZoom(){
	var percentW = getBodyWidth()  / lWidthDoc;
	var percentH = getBodyHeight() / (lHeightPage);
	var percent = percentW;
	if (percentH < percentW)
		percent = percentH;
	return percent;
}
function FitToWidthZoom(){
	var percentW = getBodyWidth()  / lWidthDoc;
	return percentW;
}
function SetPageCountToMenu(){
	SetPagesCount(nPagesCount);
}
function SetPageCountToMenu2(nCurrentCount){
	SetPagesCount(nCurrentCount);
}
function OnZoom(zoomNum){
	var _translate = "50% 0px";
	var bodyWidth = getBodyWidth();
	if (lWidthDoc >= bodyWidth){
		_translate = "0px 0px";
	}
	else{
		var translateX 	= bodyWidth / 2;
		var widthDoc2 	= lWidthDoc * zoomNum / 2;
		var minX = translateX - widthDoc2;
		if (minX < 0){
			var x_y = translateX - lWidthDoc / 2;
			offsetDoc = x_y / (zoomNum - 1);
			_translate = offsetDoc + "px 0px";
		}
	}
	var _element = document.getElementById("maindiv");
	var _scale = "scale(" + zoomNum + ")";
	if ($("#scrollbarH").scrollLeft() > 0 ){$("#scrollbarH").scrollLeft(0).scroll();}
	_element.style.Transform = _scale;
	_element.style.TransformOrigin	= _translate;
	_element.style.msTransform = _scale;
	_element.style.msTransformOrigin	= _translate;
	_element.style.MozTransform = _scale;
	_element.style.MozTransformOrigin = _translate;
	_element.style.OTransform = _scale;
	_element.style.OTransformOrigin = _translate;
	_element.style.WebkitTransform = _scale;
	_element.style.WebkitTransformOrigin = _translate;

	//var _matrix_scale = "(M11=" + zoomNum + ", M22=" + zoomNum + ")";
	//_element.style.msFilter = "progid:DXImageTransform.Microsoft.Matrix" + _matrix_scale;
	//_element.style.filter   = "progid:DXImageTransform.Microsoft.Matrix" + _matrix_scale;

	dZoomKoef = zoomNum;
	if (zoomNum < 1 && (window.chrome || window.safari)){
		var percent = 100 / zoomNum + 1;
		var Objects = document.getElementsByTagName("object");
		var nCount = Objects.length;
		for ( var i = 0; i < nCount; i++ ){
			Objects[i].style.width  = percent + "%";
			Objects[i].style.height = percent + "%";
		}
	}
	setScrollHeightZoom(zoomNum);
	horScroll();
}
function setScrollHeightZoom(zoom){
	$("#ssV").height((__arrOffset[__arrOffset.length-1] + $('.blockpage:last').height() + 2)*zoom);
	if ($.browser.safari && zoom >= 1){
		document.body.style.height = $("#ssV").height();}
	OnChangePage(currentPage);
}
function horScroll(){
	if (getBodyWidth()<lWidthDoc*dZoomKoef)
	{
		$("#scrollbarH").width($(window).width()-20);
		$("#scrollbarV").height($(window).height()-22-$("#menu").height());
		$("#vertScrollContainer").height($(window).height());
		$("#ssH").width(Math.abs(getBodyWidth()-lWidthDoc*dZoomKoef)+getBodyWidth()+20)
		$("#scrollbarH").show();
	}
	else {$("#scrollbarH").hide();$("#scrollbarV").height($(window).height()-$("#menu").height());return;}
}