var ZoomPercent = 100;var nPageNumber = 1;var nPageCount = 1;var nFirstSendZoom = 0; var fitToPage = 666;var bFitToPage = false;var actualSizeZoomPosition = 7;var speedMouseWheelScroll = 116;
var arrZoom = [8,12,25,33,50,66,75,100,125,150,200,300,400,500];var arrZoomLength = arrZoom.length; var focusEditor = undefined;var curZoomPosition = 7; var childFrameNotLoad = true;var timerID;
var trimPage = 10;

// array persents to current zoom
var arrUpdateZoom = [];
// time to update zoom
var timeUpdateZoom = 1000;
// if zoom working
var notUpdateZoom = false;

$(document).ready(function(){
	$("#ShareButton,#EditButton").bind({
		mouseenter:	function(){
						$(this).addClass('hoverbutton');
						$(this.lastChild).addClass('hoverbuttonSpan');
		},
		mouseleave:	function(){
						$(this).removeClass('hoverbutton').removeClass('hoverbuttonClick');
						$(this.lastChild).removeClass('hoverbuttonSpan').removeClass('hoverbuttonSpanClick');
		},
		mousedown:	function(){
						$(this).addClass('hoverbuttonClick');
						$(this.lastChild).addClass('hoverbuttonSpanClick');
		},
		mouseup:	function(){
						$(this).removeClass('hoverbuttonClick');
						$(this.lastChild).removeClass('hoverbuttonSpanClick');
		}
	})
	curZoomPosition = 7;
	document.getElementById('zoom').value = curZoomPosition ;
	document.getElementById('pageNum').value = nPageNumber;
	$(".selectableIcon").bind({
		mouseenter: function(){$(this).addClass("ToolbarIconOutSelect");},
		mouseleave: function(){
			$(this).removeClass("ToolbarIconOutSelect");
			if($(this).hasClass("iconPressed") && false == $(this).hasClass("iconPressed2")){
				$(this).removeClass("iconPressed")
			}; 
		},
		mousedown: function(){if(false == $(this).hasClass("iconPressed2"))$(this).addClass("iconPressed");},
		mouseup: function(){if(false == $(this).hasClass("iconPressed2"))$(this).removeClass("iconPressed");}
	});
	if(!($.browser.msie && ($.browser.version=="8.0"||$.browser.version=="7.0"))){
		$("#zoomMenu").clickMenu({onClick:function(){
				if (childFrameNotLoad) {$('#zoomMenu').trigger('closemenu');return false;}
				switch(this.id){
					case "8": curZoomPosition = 0; break;
					case "12": curZoomPosition = 1; break;
					case "25": curZoomPosition = 2; break;
					case "33": curZoomPosition = 3; break;
					case "50": curZoomPosition = 4; break;
					case "66": curZoomPosition = 5; break;
					case "75": curZoomPosition = 6; break;
					case "100": curZoomPosition = 7; break;
					case "125": curZoomPosition = 8; break;
					case "150": curZoomPosition = 9; break;
					case "200": curZoomPosition = 10; break;
					case "300": curZoomPosition = 11; break;
					case "400": curZoomPosition = 12; break;
					case "500": curZoomPosition = 13; break;
				}
				setZoomFromCurPos(curZoomPosition);
				$(".iconPressed").removeClass("iconPressed");
				bFitToPage = false;
				$('#zoomMenu').trigger('closemenu');
				return false;
			}
		});
	}
	$("#statusbar").css({width:177,height:17,top:0,left:($(window).width()-$("#statusbar").width())/2});
	$("#content").height($(window).height()-$("#menu").height()-16)
	$("#menu").click(function(){closeMenu()});
	$("#EditButton").click(function(){postMessageToPage(0)});
	$("#ShareButton").click(function(){postMessageToPage(1)});
	$("#td_load").click(function(){postMessageToPage(2)});
	$("#td_print").click(function(){
		if (childFrameNotLoad) return false;
		//document.getElementById("id_viewer").contentWindow.focus();
		//document.getElementById("id_viewer").contentWindow.print();
		//var main_div = document.getElementById("content");
		//printwin = open('', 'print', 'width=300,height=300');
		//printwin.document.open();
		//printwin.document.write('<html><head><link rel="stylesheet" href="docstyles.css" type="text/css"/><link rel="stylesheet" href="common/docviewer.css" type="text/css"/></head><body onload=print();>');
		//printwin.document.write(main_div.innerHTML);
		//printwin.document.write('</body></html>');
		//printwin.document.close();
		print();
	});
	$(document).bind({
		keydown:function(e){
			if (childFrameNotLoad) return false;
			evt = e || window.event;
			pressedKey(e);
		},
		mousewheel:function(e,delta){ 
			if (childFrameNotLoad) return false;
			funMouseWheel(e,delta);
		}
	});
	
	var buttonsVisible = $("#documentButtons").val();
	if (undefined != buttonsVisible){
		var array = buttonsVisible.split(";");
		for (var i = 0; i < array.length; ++i){
			switch(array[i]){
				case "share":
					$("#ShareButton").show();
					break;
				case "edit":
					$("#EditButton").show();
					break;
				case "download":
					$("#downloadButton").show();
					break;
			}
		}
	}
	$(window).resize(function(){
		$("#statusbar").css({width:177,height:17,top:0,left:($(window).width()-$("#statusbar").width())/2});
		if ( $("#scrollbarH").is(":visible") ){
			$("#scrollbarH").width($(window).width()-20);
			$("#scrollbarV").height($(window).height()-22);
		}
		else 
			$("#scrollbarV, .spV").height($(window).height());
		// getTopFrame().$("#vertScrollContainer").height($(window).height());			
		OnZoom(dZoomKoef);
	})
	if($.browser.msie && ($.browser.version=="8.0"||$.browser.version=="7.0")){
		$("#zoomOut,#zoomIn,#actualSize,#fitToPage,#fitToWidth").parent().css("display","none");
		$("#zoomMenu").parent().parent().css("display","none");
		$("#zoomMenu").parent().parent().next().css("display","none");
	}
	if($.browser.msie && $.browser.version=="9.0"){	$("#pageNum").css("border-color","#fff");}
		
	setTimeout(UpdateZoom, timeUpdateZoom);
	
	funOnOffStatus(0);
		ind=0
		$(".blockpage").each(function(){
			__arrOffset[ind]=$(this).offset().top; ind++;
		})
		// if (typeof(window.onscroll) == 'function')
			window.onscroll = function(){
				if(!winScroll){winScroll=true;return;}
				bOnChangePage = false;
				if ($.browser.msie)
					$("#scrollbarV").scrollTop(document.documentElement.scrollTop);
				else
					$("#scrollbarV").scrollTop(window.scrollY);
				if ( $("#scrollbarH").is(":visible") ){
					if ($.browser.msie)
						$("#scrollbarH").scrollLeft(document.documentElement.scrollLeft);
					else
						$("#scrollbarH").scrollLeft(window.scrollX);
				}
				OnScroll();
			};
		childFrameNotLoad = false;
		if (lHeightDoc > $(window).height()){$("#vertScrollContainer").show();}
		$("#scrollbarV").height($(window).height()-42);
		$("#scrollbarV, #vertScrollContainer, .spV, #ssV").click(function(){OnClick();})
		$("#ssV").height($('.blockpage:last').offset().top + $('.blockpage:last').height() + 2);
		if ($.browser.safari){document.body.style.height = $("#ssV").height();}

		$("#scrollbarV").scroll(function(evt, delta){
				// evt.stopPropagation();
				// evt.preventDefault();
				if(!bOnChangePage)
					{bOnChangePage=true;return;}
				winScroll = false;
				// if (( $.browser.safari && /chrome/.test(navigator.userAgent.toLowerCase()) ) ? false : true)
					$("#maindiv").css({top: -this.scrollTop});
				// else
					// $("#maindiv").scrollLeft(this.scrollTop);
				// $("#maindiv").scrollTop(-300);
				OnScroll();
				OnClick();
		});

		$("#scrollbarH").scroll(function(evt,delta){
			evt.stopPropagation();
			evt.preventDefault();
			// if (( $.browser.safari && /chrome/.test(navigator.userAgent.toLowerCase()) ) ? false : true)
				$("#maindiv").css({left: -this.scrollLeft});
			// else
				// $("#maindiv").scrollLeft(this.scrollLeft);
			OnClick();
		})
});
function UpdateZoom(){
	if (false == notUpdateZoom && 0 < arrUpdateZoom.length){
		notUpdateZoom = true;
		var currentZoom = arrUpdateZoom [arrUpdateZoom.length - 1];
		nFirstSendZoom = 1;
		setZoom (currentZoom);
		arrUpdateZoom.splice(0, arrUpdateZoom.length)
		notUpdateZoom = false;
	}
	setTimeout (UpdateZoom, timeUpdateZoom);
}
function CheckFitToPage(){
	if ($("#td_fitToPage").hasClass("iconPressed"))
		funZoom(1,null);
	else if ($("#td_fitToWidth").hasClass("iconPressed"))
		funZoom(2,null);
}
function closeMenu(){
	$('#zoomMenu').trigger('closemenu');
}
function setZoom(dZoom) {
	ZoomPercent = dZoom;
		if (0 != nFirstSendZoom)
		{
			UpdateBodyScroll();
			sendZoomToControl(ZoomPercent);
		}
		nFirstSendZoom = 1;
}
function OnPagePrev(){
	if (childFrameNotLoad) return false;
	if (nPageNumber > 1){
		var pageNum = nPageNumber - 1;
		sendPageNumberToMenu(pageNum);
	}
}
function OnPageNext(){
	if (childFrameNotLoad) return false;
	if (nPageNumber < nPageCount){
		var pageNum = nPageNumber + 1;
		sendPageNumberToMenu(pageNum);
	}
}
function OnChangePageNum(){
	if (childFrameNotLoad) return false;
	var element = document.getElementById('pageNum');
	if (element != null){
		var number = parseInt(element.value);
		if (1 <= number && number <= nPageCount){
			nPageNumber = number;
			sendPageNumberToControl(nPageNumber);
		}
		else {element.value = nPageNumber; oInfoMessage.show($("#WrongNumber").val());}
	}
}
function SetPagesCount(pageCount){
	nPageCount = pageCount;
	$("#pageCounts").text('/ '+nPageCount);
}
// send to viewer -------------------------------------------------------------------------------------
function sendZoomToControl(zoomValue){
	var part = zoomValue / 100.0;
	OnZoom(part);
}
function sendPageNumberToControl(pageNumber){
	OnChangePage(pageNumber);
}
//---------------------------------------------------------------------------------------------------------
// send to menu (according to viewer) -----------------------------------------------------------
function sendPageNumberToMenu(pageNumber){
	if ((nPageNumber != pageNumber) && (1 <= pageNumber) && (pageNumber <= nPageCount)){
		nPageNumber = pageNumber;
		document.getElementById('pageNum').value = nPageNumber;
		sendPageNumberToControl(nPageNumber);
	}
}
function funZoomIn(){
if (childFrameNotLoad) return false;
	if(curZoomPosition < arrZoomLength - 1){
		$(".iconPressed").removeClass("iconPressed")
		if (bFitToPage){curZoomPosition += 0.5;bFitToPage = false;}
		else curZoomPosition++;
		setZoomFromCurPos(curZoomPosition);
	}
};
function funZoomOut(){
if (childFrameNotLoad) return false;
	if(curZoomPosition > 0){
		$(".iconPressed").removeClass("iconPressed")
		if (bFitToPage){curZoomPosition -= 0.5;bFitToPage = false;}
		else curZoomPosition--;
		setZoomFromCurPos(curZoomPosition);
	}
};
function setZoomFromCurPos(curPos){
	arrUpdateZoom[arrUpdateZoom.length] = arrZoom[curPos];
	$(".dropdown").css({float:'right'});
	setZoomMenuValue(curPos);
}
function setZoomMenuValue(curPos){
	$('#zoomValuePercent').text(arrZoom[curPos]+'%');
	$('#zoomValuePercent').val(arrZoom[curPos]);
}
function postMessageToPage(type){
	if (childFrameNotLoad) return false;
	switch (type){
		case 0: rdata={type:'edit',guid:'EDIT'}; break;
		case 1: rdata={type:'share',guid:'SHARE'}; break;
		case 2: rdata={type:'download',guid:'DOWNLOAD'}; break;
	}
	parent.postMessage(JSON.stringify(rdata),"*");
}
function UpdateBodyScroll(){
	var dMemoryZoom = ZoomPercent / 100;
	var _main_div = document.getElementById('maindiv');
	if (null != _main_div){
		var newHeight = dMemoryZoom * lHeightDoc;
		if (1 <= dMemoryZoom){
			_main_div.style.height 				= "";
			//_frame.document.body.style.height 	= newHeight + 16;
		}
		else{
			if (null != _main_div){
				//_frame.document.body.style.height 	= "";
				_main_div.style.height 				= newHeight + "px";
			}
		}
	}
}
function SetCurrentPage(PageNum){
	nPageNumber = PageNum;
	document.getElementById('pageNum').value = PageNum;
}
function setCurrentZoomPositionAfterFitToPage(zoomPercent){
	for (var i=1; i<arrZoom.length-1; i++){
		if (zoomPercent >= arrZoom[i] && zoomPercent <= arrZoom[i+1]){
			curZoomPosition = i+0.5;
			bFitToPage = true;
			break;
		}
		if ( zoomPercent < arrZoom[0]){curZoomPosition = -0.5;}
		if ( zoomPercent > arrZoom[arrZoom.length-1] ){curZoomPosition = arrZoom.length-1+0.5;}
	}
}
function funOnOffStatus(onoff,statuscolor,statustext){
	if (onoff == 0)
		{$("#statusbar").hide();return;}
	if (onoff == 1)
		{$("#statusbar").show();$("#netstatus").css("background-color", statuscolor).text(statustext);return;}
}
function onlyNumber(_f3a,e,dec){
	var key;
	var _f3e;
	if(window.event){
		key=window.event.keyCode;
	}else{
		if(e){
			key=e.which;
		}else{
			return true;
		}
	}
	_f3e=String.fromCharCode(key);
	if(key==13){
		OnChangePageNum();
	}
	if((key==null)||(key==0)||(key==8)||(key==9)||(key==13)||(key==27)){
		return true;
	}else{
		if((("0123456789").indexOf(_f3e)>-1)){
			return true;
		}else{
			if(dec&&(_f3e==".")){
				_f3a.form.elements[dec].focus();
				return false;
			}else{
				return false;
			}
		}
	}
}
function pressedKey(e){
	if(e.ctrlKey){
		switch(e.keyCode){
			case 80: // Ctrl+P - print
				e.stopPropagation();
				e.preventDefault();
				$("#td_print").click();
				break;
			case 43:
			case 107:
			case 187: //Ctrl++
				e.stopPropagation();
				e.preventDefault();
				if($.browser.msie && ($.browser.version=="8.0"||$.browser.version=="7.0")) break;
					funZoomIn();
				break;
			case 45:
			case 109:
			case 189: //Ctrl+-
				e.stopPropagation();
				e.preventDefault();
				if($.browser.msie && ($.browser.version=="8.0"||$.browser.version=="7.0")) break;
					funZoomOut();
				break;
			case 48:
			case 96://Ctrl+0
				e.stopPropagation();
				e.preventDefault();
				if($.browser.msie && ($.browser.version=="8.0"||$.browser.version=="7.0")) break;
					funZoom(0,null)
				break;
		}
	}
	else {
		switch(e.keyCode){
			case 35://End
				e.stopPropagation();
				e.preventDefault();
				sendPageNumberToControl(nPageCount);
				break;
			case 36://Home
				e.stopPropagation();
				e.preventDefault();
				sendPageNumberToControl(1);
				break;
			case 33://PageUp
				e.stopPropagation();
				e.preventDefault();
				scrollMouseWheel(lHeightPage/(2*speedMouseWheelScroll));
				break;
			case 34://PageDown
				e.stopPropagation();
				e.preventDefault();
				scrollMouseWheel(-lHeightPage/(2*speedMouseWheelScroll));
				break;
			case 38://Arrow Up
				e.stopPropagation();
				e.preventDefault();
				scrollMouseWheel(1);
				break;
			case 40://Arrow Down
				e.stopPropagation();
				e.preventDefault();
				scrollMouseWheel(-1);
				break;
		}
	}
}
function funMouseWheel(e,delta){
	if (e.ctrlKey){
		e.stopPropagation();
		e.preventDefault();
		if($.browser.msie && ($.browser.version=="8.0"||$.browser.version=="7.0")) return false;
		if (delta<0){funZoomOut();}
		if (delta > 0){funZoomIn();}
	}
	else scrollMouseWheel(delta);
}
function scrollMouseWheel(delta)
{
var st1=$("#scrollbarV").scrollTop();
$("#scrollbarV").scrollTop(st1 - speedMouseWheelScroll * delta );
}
function funZoom(type,elem){
	//type == 0 - set 100% zoom
	//type == 1 - set FitToPage
	//type == 2 - set FitToWidth
	if (childFrameNotLoad) return false;
	percent = 100;
	if (type == 1 || type == 2){
		if (null != elem){
			$(".iconPressed").removeClass("iconPressed")
			$(elem).addClass('iconPressed');
		}

			switch (type){
				case 1:percent = FitToPageZoom() * 100;break;
				case 2:percent = FitToWidthZoom() * 100;break;
			}
			$('#zoomValuePercent').text(Math.floor(percent)+"%");
			setCurrentZoomPositionAfterFitToPage(Math.floor(percent));
			arrUpdateZoom[arrUpdateZoom.length] = percent;

		return true;
	}
	if (type == 0){
		$(".iconPressed").removeClass("iconPressed")
		bFitToPage = false;
		curZoomPosition = actualSizeZoomPosition;
		setZoomMenuValue(actualSizeZoomPosition);
		arrUpdateZoom[arrUpdateZoom.length] = arrZoom[actualSizeZoomPosition];
		return true;
	}
	return false;
}
function startTimer(){
	timerID = setInterval(function(){
			if (__pagesLoaded!=undefined)
				{SetPagesCount(__pagesLoaded);}
		},
		trimPage
	);
}
function stopTimer(){clearInterval(timerID);}